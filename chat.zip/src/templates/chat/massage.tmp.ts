export const massage: string = `<div class="talk__message">{{massageText}}</div>`
