export const talkUserTmp: string = `<div class="talk__user">
<div class="talk__user-info">
  <div class="talk__user-avatar"></div>
  <div class="talk__user-name">{{name}}</div>
</div>
<button class="talk__bar"></button>
</div>`
