export const companionTmp: string = `<li class="chat__companion companion">
<div class="companion__avatar"></div>
<p class="companion__name">{{name}}</p>
<p class="companion__last-massage">{{lastMassage}}</p>
<time class="companion__time">{{time}}</time>
<div class="companion__not-read-massage">{{notReadMassage}}</div>
</li>`
