export const replyFormFiemlTmp: string = `<label class="form__field talk__form-field">
<input
  name="{{inputName}}"
  type="text"
  autocomplete="off"
  class="talk__input talk__input-message"
  placeholder="Сообщение"
/>
<span class='form__input-error talk__input-error'>{{errorText}}</span>
</label>`
