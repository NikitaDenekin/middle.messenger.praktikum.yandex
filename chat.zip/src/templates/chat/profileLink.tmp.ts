export const profileLinkTmp: string = `<a id="chat-btn-profile" class="chat__btn-profile">
Профиль >
</a>`
