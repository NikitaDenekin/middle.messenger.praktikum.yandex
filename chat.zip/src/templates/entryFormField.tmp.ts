export const entryformFiemlTmp: string = `<label class="form__field">
<p class='form__input-title'>{{name}}</p>
<input required type='text' name={{inputName}}  class='form__input entry__input' />
<span class='form__input-error'>{{errorText}}</span>
</label>`
