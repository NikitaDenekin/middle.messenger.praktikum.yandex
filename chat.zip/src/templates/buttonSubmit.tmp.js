export const buttonSubmitTmp = `<button class="form__btn form__btn-signup" type="submit">{{buttonText}}</button>`
