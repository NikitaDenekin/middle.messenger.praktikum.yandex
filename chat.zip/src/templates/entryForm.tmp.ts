export const entryFormTmp: string = `<form novalidate class="form entry__form entry__form-signin">
{{#each fields}}
  {{{this}}}
{{/each}}
<button class="form__btn form__btn-signup" type="submit">{{buttonText}}</button>
</form>`
