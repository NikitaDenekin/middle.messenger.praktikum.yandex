export const profileTmp: string = `<div class="profile">
{{{buttonBack}}}
<div class="profile__preview">
  <div class="profile__preview-avatar"></div>
  <div class="profile__preview-name">Иван</div>
</div>
{{{profileInfo}}}
<div class="profile__bar">
{{{buttonEdibInfo}}}
{{{buttonEditPassword}}}
{{{buttonExit}}}
</div>
</div>`
