export const profileBtnTmpl: string = `<button type="button" class="profile__btn">{{buttonText}}</button>`
