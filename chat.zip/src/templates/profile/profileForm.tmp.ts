export const profileFormTmp: string = `<form class="profile__info profile__form-edit-info">
{{#each fields}}
  {{{this}}}
{{/each}}
<button  type="submit" class="form__btn profile__btn-submit">Сохранить</button>
</form>`
