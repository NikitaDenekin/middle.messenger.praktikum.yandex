export const profileFormFieldTmp: string = `<label class="profile__item">
<p class="profile__item-name">{{name}}</p>
<input name="{{inputName}}" class="profile__item-value" placeholder="{{data}}"/>
<span class='form__input-error'>{{errorText}}</span>
</label>`
