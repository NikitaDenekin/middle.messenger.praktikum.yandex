export const profileButtonBackTmp: string = `<button id="profile-btn-back" class="profile__btn-back"></button>`
