export const loginTmp: string = `<div class="entry">
<div class="entry__container">
  <h2 class="entry__title">Вход</h2>
  {{{form}}}
  {{{link}}}
</div>
</div>`
