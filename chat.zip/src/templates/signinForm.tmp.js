export const signinFormTmp = `<form onsubmit="return false" class="form entry__form entry__form-signin">
{{{emailField}}}
{{{loginField}}}
{{{nameField}}}
{{{secondNameField}}}
{{{phoneField}}}
{{{passwordField}}}
{{{nextPasswordField}}}
{{{button}}}
</form>`
