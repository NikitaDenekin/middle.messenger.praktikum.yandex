export const entryLinkTmp: string = `<a href="{{path}}" class="entry__btn">{{buttonText}}</a>`
